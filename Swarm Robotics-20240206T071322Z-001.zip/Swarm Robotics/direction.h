#include <ESP8266WiFi.h>
void forward(int PWM1, int PWM2, int pwr,int mL1,int mL2,int mR1,int mR2){
  analogWrite(PWM1,pwr);
  analogWrite(PWM2,pwr);
  digitalWrite(mL1, HIGH);
  digitalWrite(mL2, LOW);
  digitalWrite(mR1, HIGH);
  digitalWrite(mR2, LOW);
}
void backward(int PWM1, int PWM2, int pwr,int mL1,int mL2,int mR1,int mR2){
  analogWrite(PWM1,pwr);
  analogWrite(PWM2,pwr);
  digitalWrite(mL1, LOW);
  digitalWrite(mL2, HIGH);
  digitalWrite(mR1, LOW);
  digitalWrite(mR2, HIGH);

}
void turnright(int PWM1, int PWM2, int pwr,int mL1,int mL2,int mR1,int mR2){
  analogWrite(PWM1,pwr);  
  analogWrite(PWM2,pwr);
  digitalWrite(mL1, HIGH);
  digitalWrite(mL2, LOW);
  digitalWrite(mR1, LOW);
  digitalWrite(mR2, HIGH);

}
void turnleft(int PWM1, int PWM2, int pwr,int mL1,int mL2,int mR1,int mR2){
  analogWrite(PWM1,pwr);
  analogWrite(PWM2,pwr);
  digitalWrite(mL1, LOW);
  digitalWrite(mL2, HIGH);
  digitalWrite(mR1, HIGH);
  digitalWrite(mR2, LOW);

}
void stop(int PWM1, int PWM2, int pwr,int mL1,int mL2,int mR1,int mR2){
  analogWrite(PWM1,pwr);
  analogWrite(PWM2,pwr);
  digitalWrite(mL1, LOW);
  digitalWrite(mL2, LOW);
  digitalWrite(mR1, LOW);
  digitalWrite(mR2, LOW);

}